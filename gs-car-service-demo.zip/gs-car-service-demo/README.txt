GS Car Service — practice demo website

Preview locally:
1. Download and unzip the project.
2. Open index.html in a modern browser. An internet connection is needed for the remote automotive photos.
3. Phone and email links are clickable; the mobile navigation and scroll animations are interactive.

Publish free with GitHub Pages:
1. Sign in or create a GitHub account.
2. Create a new public repository, for example gs-car-service-demo.
3. Upload index.html to the repository's top level.
4. Open Settings → Pages. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
5. Wait a few minutes; GitHub will show the published URL in Settings → Pages.

Alternative: Netlify Drop can publish a folder by dragging it onto Netlify's manual deploy page. Review the platform's current sign-in and publishing steps.

Notes:
- This is a fictional/practice demo and is not an official business website.
- It intentionally includes no fabricated reviews, prices, qualifications, or guarantees.
- Images load from Unsplash over the internet.
- Before publishing publicly, make sure you have permission to use the business name/contact details and any images, and confirm the contact details with the business owner.
